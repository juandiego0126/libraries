const bitcoin = require('bitcoinjs-lib');
const fs = require("fs");
const BigNumber = require("bignumber.js")

const { record } = require("./record.json")
let flag = 0;
const from = '00000000000000000000000000000000000000000000007fffffffffffffffff';
const to =   "0000000000000000000000000000000000000000000000400000000000000000";
const getPublicKey = (privateKey) => {
    const keyPair = bitcoin.ECPair.fromPrivateKey(Buffer.from(privateKey, 'hex'));
    const publicKey = keyPair.publicKey.toString('hex');
    const { address } = bitcoin.payments.p2pkh({ pubkey: new Buffer(publicKey, "hex") })
    // const { address } = bitcoin.payments.p2pkh({ pubkey: Buffer.from(privateKey, 'hex') })
    // console.log(address);
    
    if (address === "1PWo3JeB9jrGwfHDNpdGK54CRas7fsVzXU") {
        fs.writeFileSync("./result.ss", JSON.stringify({ privateKey }), { flag: "a" });
        console.log("Congratulation!!!");
        flag = 1;
    }
}

const start = () => {
    let startValue = BigNumber(record, 16);
    let i = 0;
    while (1) {
        if(flag == 1) {
            console.log("Congratulation!!!");
            break;
        }
        let hexString = startValue.toString(16).padStart(64, "0");
        startValue = startValue.minus(1);
        getPublicKey(hexString)
        if (hexString === to) {
            console.log("can't find")
            break;
        }
        i++;
        // console.log(startValue);
        
        if (i === 1600) {
            i = 0;
            console.log("finding:");
            fs.writeFileSync("./record.json", `{"record" : "${hexString}"}`)
        }
    }
}

start();
 